package lockedout.sae.vehiculemicroservice.FeignClient;

import lockedout.sae.vehiculemicroservice.entities.DAO.Cost;
import lockedout.sae.vehiculemicroservice.entities.DAO.Document;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "COSTSMICROSERVICE")
public interface CostFeign {
    @PostMapping("/costs")
    Cost createCost(@RequestBody Cost cost);

    @GetMapping("/costs/{id}")
    Cost getCostById(@PathVariable("id") Long id);

    @PutMapping("/costs/{id}")
    Cost updateCost(@PathVariable("id") Long id, @RequestBody Cost cost);

    @DeleteMapping("/costs/{id}")
    void deleteCostById(@PathVariable("id") Long id);

    @GetMapping("/costs/vehicle/{vehicleId}")
    List<Cost> getAllCostsForVehicle(@PathVariable("vehicleId") Long vehicleId);


}
