package lockedout.sae.vehiculemicroservice.FeignClient;

import lockedout.sae.vehiculemicroservice.entities.DAO.Trip;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "TRIPSMICROSERVICE")
public interface TripFeign {
    @PostMapping("/trips")
    Trip createTrip(@RequestBody Trip trip);

    @GetMapping("/trips/{id}")
    Trip getTripById(@PathVariable("id") Long id);

    @PutMapping("/trips/{id}")
    Trip updateTrip(@PathVariable("id") Long id, @RequestBody Trip trip);

    @DeleteMapping("/trips/{id}")
    void deleteTrip(@PathVariable("id") Long id);

    @GetMapping("/trips/vehicle/{vehicleId}")
    List<Trip> getAllTripsForVehicle(@PathVariable("vehicleId") Long vehicleId);

}
