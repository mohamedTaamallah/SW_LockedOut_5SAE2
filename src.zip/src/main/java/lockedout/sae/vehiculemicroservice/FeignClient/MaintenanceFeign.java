package lockedout.sae.vehiculemicroservice.FeignClient;

import lockedout.sae.vehiculemicroservice.entities.DAO.Document;
import lockedout.sae.vehiculemicroservice.entities.DAO.Maintenance;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "MAINTENANCEMICROSERVICE")
public interface MaintenanceFeign {
    @PostMapping("/maintenances")
    Maintenance createMaintenance(@RequestBody Maintenance maintenance);

    @GetMapping("/maintenances/{id}")
    Maintenance getMaintenanceById(@PathVariable("id") Long id);

    @PutMapping("/maintenances/{id}")
    Maintenance updateMaintenance(@PathVariable("id") Long id, @RequestBody Maintenance maintenance);

    @DeleteMapping("/maintenances/{id}")
    void deleteMaintenance(@PathVariable("id") Long id);

    @GetMapping("/maintenances/vehicle/{vehicleId}")
    List<Maintenance> getAllMaintenanceForVehicle(@PathVariable("vehicleId") Long vehicleId);
}
