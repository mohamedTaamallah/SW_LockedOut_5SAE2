package lockedout.sae.vehiculemicroservice.implementation.services;

import java.util.List;
import java.util.NoSuchElementException;

import lockedout.sae.vehiculemicroservice.FeignClient.CostFeign;
import lockedout.sae.vehiculemicroservice.FeignClient.DocumentFeign;
import lockedout.sae.vehiculemicroservice.FeignClient.MaintenanceFeign;
import lockedout.sae.vehiculemicroservice.FeignClient.TripFeign;
import lockedout.sae.vehiculemicroservice.entities.DAO.Cost;
import lockedout.sae.vehiculemicroservice.entities.DAO.Document;
import lockedout.sae.vehiculemicroservice.entities.DAO.Maintenance;
import lockedout.sae.vehiculemicroservice.entities.DAO.Trip;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lockedout.sae.vehiculemicroservice.entities.Vehicle;
import lockedout.sae.vehiculemicroservice.implementation.interfaces.IVehicleImp;
import lockedout.sae.vehiculemicroservice.repositories.VehicleRepository;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class VehicleImp implements IVehicleImp{

    private VehicleRepository vehicleRepository;
    @Autowired
    private DocumentFeign DocumentFeign;
    @Autowired
    private CostFeign CostFeign;
    @Autowired
    private TripFeign tripFeign;
    @Autowired

    private final MaintenanceFeign maintenanceFeign;

    public List<Document> getAllDocuments() {
        return DocumentFeign.getAllDocuments();
    }

    public Document getDocumentById(Long id) {
        return DocumentFeign.getDocumentById(id);
    }

    @Override
    public Vehicle addVehicle(Vehicle vehicle) {

        if (vehicle.getRegistrationNumber() == null || vehicle.getRegistrationNumber().isEmpty()) {
            throw new IllegalArgumentException("Registration number cannot be null or empty");
        }


        if (vehicleRepository.findByRegistrationNumber(vehicle.getRegistrationNumber()) != null) {
            throw new IllegalArgumentException("Vehicle with this registration number already exists");
        }

        return vehicleRepository.save(vehicle);
    }

    @Override
    public Vehicle getVehicleById(Long vehicleId) {
        return this.vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new NoSuchElementException("Vehicle not found"));
    }

    @Override
    public Vehicle updateVehicle(Long vehicleId,Vehicle vehicle) {
        Vehicle existingVehicle = this.getVehicleById(vehicleId);
        existingVehicle.setRegistrationNumber(vehicle.getRegistrationNumber());
        existingVehicle.setMileage(vehicle.getMileage());
        existingVehicle.setBrand(vehicle.getBrand());
        existingVehicle.setModel(vehicle.getModel());
        existingVehicle.setYear(vehicle.getYear());
        existingVehicle.setType(vehicle.getType());
        existingVehicle.setFuelCapacity(vehicle.getFuelCapacity());
        existingVehicle.setAverageConsumption(vehicle.getAverageConsumption());
        return this.vehicleRepository.save(existingVehicle);
    }

    @Override
    public Vehicle deleteVehicle(Long vehicleId) {
        Vehicle existingVehicle = this.getVehicleById(vehicleId);
        this.vehicleRepository.delete(existingVehicle);
        return existingVehicle;

    }

    @Override
    public Vehicle findByRegistrationNumber(String registrationNumber) {
        return this.vehicleRepository.findByRegistrationNumber(registrationNumber);
    }

    @Override
    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    public Document addDocumentToVehicle(Long vehicleId, Document document) {
        // Set the vehicleId on the document
        document.setVehicleId(vehicleId);

        // Call DocumentService to save the document with the vehicleId
        return DocumentFeign.addDocument(document);
    }
    @Override
    public Document updateDocumentForVehicle(Long vehicleId, Long documentId, Document document) {
        // Retrieve the document to verify its association with the vehicle
        Document existingDocument = DocumentFeign.getDocumentById(documentId);

        if (existingDocument.getVehicleId().equals(vehicleId)) {
            // Update the document details
            document.setVehicleId(vehicleId); // Ensure the vehicleId is maintained
            return DocumentFeign.updateDocument(documentId, document);
        } else {
            throw new IllegalArgumentException("Document does not belong to the specified vehicle.");
        }
    }

    @Override
    public void deleteDocumentForVehicle(Long vehicleId, Long documentId) {
        // Retrieve the document to verify its association with the vehicle
        Document existingDocument = DocumentFeign.getDocumentById(documentId);

        if (existingDocument.getVehicleId().equals(vehicleId)) {
            // Delete the document
            DocumentFeign.deleteDocument(documentId);
        } else {
            throw new IllegalArgumentException("Document does not belong to the specified vehicle.");
        }
    }

    public Cost addCostToVehicle(Long vehicleId, Cost cost) {
        cost.setVehicleId(vehicleId); // Associate the cost with the vehicle
        return CostFeign.createCost(cost);
    }

    public Cost getCostByIdForVehicle(Long vehicleId, Long costId) {
        Cost cost = CostFeign.getCostById(costId);
        if (cost != null && cost.getVehicleId().equals(vehicleId)) {
            return cost;
        } else {
            throw new IllegalArgumentException("Cost does not belong to the specified vehicle.");
        }
    }

    public List<Cost> getAllCostsForVehicle(Long vehicleId) {
        return CostFeign.getAllCostsForVehicle(vehicleId);
    }

    public Cost updateCostForVehicle(Long vehicleId, Long costId, Cost cost) {
        Cost existingCost = CostFeign.getCostById(costId);
        if (existingCost != null && existingCost.getVehicleId().equals(vehicleId)) {
            cost.setVehicleId(vehicleId); // Ensure the association remains intact
            return CostFeign.updateCost(costId, cost);
        } else {
            throw new IllegalArgumentException("Cost does not belong to the specified vehicle.");
        }
    }

    public void deleteCostForVehicle(Long vehicleId, Long costId) {
        Cost existingCost = CostFeign.getCostById(costId);
        if (existingCost != null && existingCost.getVehicleId().equals(vehicleId)) {
            CostFeign.deleteCostById(costId);
        } else {
            throw new IllegalArgumentException("Cost does not belong to the specified vehicle.");
        }
    }
    public Cost getCostById(Long costId) {
        return CostFeign.getCostById(costId);
    }
    public Trip addTripToVehicle(Long vehicleId, Trip trip) {
        trip.setVehicleId(vehicleId); // Associate the trip with the vehicle
        return tripFeign.createTrip(trip);
    }

    public Trip getTripByIdForVehicle(Long vehicleId, Long tripId) {
        Trip trip = tripFeign.getTripById(tripId);
        if (trip != null && trip.getVehicleId().equals(vehicleId)) {
            return trip;
        } else {
            throw new IllegalArgumentException("Trip does not belong to the specified vehicle.");
        }
    }

    public List<Trip> getAllTripsForVehicle(Long vehicleId) {
        return tripFeign.getAllTripsForVehicle(vehicleId);
    }

    public Trip updateTripForVehicle(Long vehicleId, Long tripId, Trip trip) {
        Trip existingTrip = tripFeign.getTripById(tripId);
        if (existingTrip != null && existingTrip.getVehicleId().equals(vehicleId)) {
            trip.setVehicleId(vehicleId); // Ensure the association remains intact
            return tripFeign.updateTrip(tripId, trip);
        } else {
            throw new IllegalArgumentException("Trip does not belong to the specified vehicle.");
        }
    }

    public void deleteTripForVehicle(Long vehicleId, Long tripId) {
        Trip existingTrip = tripFeign.getTripById(tripId);
        if (existingTrip != null && existingTrip.getVehicleId().equals(vehicleId)) {
            tripFeign.deleteTrip(tripId);
        } else {
            throw new IllegalArgumentException("Trip does not belong to the specified vehicle.");
        }
    }
    public Maintenance addMaintenanceToVehicle(Long vehicleId, Maintenance maintenance) {
        maintenance.setVehiculeId(vehicleId); // Set the vehicle ID
        return maintenanceFeign.createMaintenance(maintenance);
    }

    public Maintenance getMaintenanceByIdForVehicle(Long vehicleId, Long maintenanceId) {
        Maintenance maintenance = maintenanceFeign.getMaintenanceById(maintenanceId);
        if (maintenance.getVehiculeId().equals(vehicleId)) {
            return maintenance;
        } else {
            throw new IllegalArgumentException("Maintenance does not belong to the specified vehicle.");
        }
    }

    public List<Maintenance> getAllMaintenanceForVehicle(Long vehicleId) {
        return maintenanceFeign.getAllMaintenanceForVehicle(vehicleId);
    }

    public Maintenance updateMaintenanceForVehicle(Long vehicleId, Long maintenanceId, Maintenance maintenance) {
        Maintenance existingMaintenance = maintenanceFeign.getMaintenanceById(maintenanceId);
        if (existingMaintenance.getVehiculeId().equals(vehicleId)) {
            maintenance.setVehiculeId(vehicleId); // Ensure vehicle ID is maintained
            return maintenanceFeign.updateMaintenance(maintenanceId, maintenance);
        } else {
            throw new IllegalArgumentException("Maintenance does not belong to the specified vehicle.");
        }
    }

    public void deleteMaintenanceForVehicle(Long vehicleId, Long maintenanceId) {
        Maintenance existingMaintenance = maintenanceFeign.getMaintenanceById(maintenanceId);
        if (existingMaintenance.getVehiculeId().equals(vehicleId)) {
            maintenanceFeign.deleteMaintenance(maintenanceId);
        } else {
            throw new IllegalArgumentException("Maintenance does not belong to the specified vehicle.");
        }
    }

}
