package lockedout.sae.vehiculemicroservice.entities.DAO;

public enum MaintenanceType {
    OilChange,TireChange,BrakeReplacement,EngineCheck,BatteryReplacement
}
