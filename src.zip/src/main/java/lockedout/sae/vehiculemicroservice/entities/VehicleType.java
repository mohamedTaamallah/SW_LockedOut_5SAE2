package lockedout.sae.vehiculemicroservice.entities;

public enum VehicleType {
    CAR,
    MOTORCYCLE,
    BICYCLE,
    TRUCK,
    BUS,
}
