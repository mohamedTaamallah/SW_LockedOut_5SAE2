package lockedout.sae.vehiculemicroservice.entities.DAO;

public enum Status {
    Pending,Completed,Overdue
}
