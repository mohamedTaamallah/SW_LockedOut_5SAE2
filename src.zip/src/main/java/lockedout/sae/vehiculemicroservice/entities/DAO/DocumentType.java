package lockedout.sae.vehiculemicroservice.entities.DAO;

public enum DocumentType {
    INSURANCE,
    REGISTRATION,
    LICENSE,
    VEHICLE_PERMIT,
    ROAD_TAX
}
