package lockedout.sae.vehiculemicroservice.entities.DAO;

public enum CostType {
    FUEL,
    MAINTENANCE,
    INSURANCE,
    OTHER
}
