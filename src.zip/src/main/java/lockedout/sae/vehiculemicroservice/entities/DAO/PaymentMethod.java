package lockedout.sae.vehiculemicroservice.entities.DAO;

public enum PaymentMethod {
    CASH,
    CREDIT_CARD,
    BANK_TRANSFER,
    OTHER
}
