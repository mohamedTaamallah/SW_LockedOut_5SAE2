package lockedout.sae.vehiculemicroservice.controllers;

import lockedout.sae.vehiculemicroservice.entities.DAO.Cost;
import lockedout.sae.vehiculemicroservice.implementation.services.VehicleImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/costs/vehicle/{vehicleId}")
public class CostController {

    @Autowired
    private VehicleImp costService;

    @PostMapping
    public ResponseEntity<Cost> addCostToVehicle(@PathVariable Long vehicleId, @RequestBody Cost cost) {
        Cost createdCost = costService.addCostToVehicle(vehicleId, cost);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdCost);
    }

    @GetMapping("/{costId}")
    public ResponseEntity<Cost> getCostByIdForVehicle(@PathVariable Long vehicleId, @PathVariable Long costId) {
        return ResponseEntity.ok(costService.getCostByIdForVehicle(vehicleId, costId));
    }

    @GetMapping
    public ResponseEntity<List<Cost>> getAllCostsForVehicle(@PathVariable("vehicleId") Long vehicleId)
    {
        return ResponseEntity.ok(costService.getAllCostsForVehicle(vehicleId));
    }

    @PutMapping("/{costId}")
    public ResponseEntity<Cost> updateCostForVehicle(@PathVariable Long vehicleId, @PathVariable Long costId, @RequestBody Cost cost) {
        return ResponseEntity.ok(costService.updateCostForVehicle(vehicleId, costId, cost));
    }

    @DeleteMapping("/{costId}")
    public ResponseEntity<Void> deleteCostForVehicle(@PathVariable Long vehicleId, @PathVariable Long costId) {
        costService.deleteCostForVehicle(vehicleId, costId);
        return ResponseEntity.noContent().build();
    }
}
