package lockedout.sae.vehiculemicroservice.repositories;

import lockedout.sae.vehiculemicroservice.entities.DAO.Trip;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TripRepository  extends JpaRepository<Trip,Long> {
}
